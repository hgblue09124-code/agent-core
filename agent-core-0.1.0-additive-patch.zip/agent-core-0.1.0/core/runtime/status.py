# core/runtime/status.py
"""Agent Status — coarse, UI-facing derivation of the agent's current activity.

Additive module. Does not replace or modify any existing status/phase model.
`AgentStatus` is a *view* over the existing `core.events.schema.EventPhase` /
`EventStatus` vocabulary — no new event architecture is introduced. It answers
one question a personal-agent UI needs continuously: "what is my agent doing
right now?" (ready / thinking / running / offline).

Derivation is intentionally conservative: if nothing is known, the agent is
READY. If the vault/storage layer reports itself unavailable, the agent is
OFFLINE, because Core cannot safely operate without its persistence layer.
Otherwise the coarse bucket is derived from the phase of the most recent
event on the shared EventBus.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional

from core.events.schema import AgentEvent, EventPhase


class AgentStatus(str, Enum):
    """Coarse agent activity status, for UI consumption."""

    READY = "READY"
    THINKING = "THINKING"
    RUNNING = "RUNNING"
    OFFLINE = "OFFLINE"


# Phases that represent "reasoning about what to do" (pre-execution).
THINKING_PHASES = frozenset(
    {
        EventPhase.TASK_CREATED.value,
        EventPhase.TASK_STARTED.value,
        EventPhase.PLAN.value,
        EventPhase.PLAN_CREATED.value,
        EventPhase.KNOWLEDGE.value,
    }
)

# Phases that represent "doing the work" (execution/verification/recording).
RUNNING_PHASES = frozenset(
    {
        EventPhase.ACTION_STARTED.value,
        EventPhase.EXECUTE.value,
        EventPhase.ACTION_COMPLETED.value,
        EventPhase.OBSERVE.value,
        EventPhase.VERIFY.value,
        EventPhase.VERIFICATION_FAILED.value,
        EventPhase.RECOVERY.value,
        EventPhase.CHECKPOINT.value,
        EventPhase.EXPERIENCE.value,
        EventPhase.EXPERIENCE_RECORDED.value,
        EventPhase.EVALUATION.value,
    }
)

# Phases that represent "the run is finished" -> back to READY.
TERMINAL_PHASES = frozenset(
    {
        EventPhase.TASK_COMPLETED.value,
        EventPhase.TASK_FAILED.value,
        EventPhase.RESULT.value,
    }
)


def derive_agent_status(
    vault_available: bool,
    last_event: Optional[AgentEvent],
) -> AgentStatus:
    """Pure derivation function — no I/O, easy to unit test.

    Args:
        vault_available: real storage-operational signal (prefer
            `PersonalVaultAdapter.is_operational()`; `is_available()` alone
            reports only whether an *external* vault is attached, which is
            False in the normal local-first mode and would misreport
            OFFLINE -- see `Agent.current_status()`).
        last_event: the most recent `AgentEvent` published on the shared
            `EventBus` (across all runs), or None if nothing has run yet.
    """
    if not vault_available:
        return AgentStatus.OFFLINE

    if last_event is None:
        return AgentStatus.READY

    phase = last_event.phase
    if phase in TERMINAL_PHASES:
        return AgentStatus.READY
    if phase in THINKING_PHASES:
        return AgentStatus.THINKING
    if phase in RUNNING_PHASES:
        return AgentStatus.RUNNING
    return AgentStatus.READY
