# core/capabilities/connections.py
"""Connections — UI-facing local/remote status over real registered capabilities.

Additive only. Does not change `BaseCapabilityAdapter`'s abstract contract
(no new abstract method). "Configured" is checked via optional duck-typed
`is_configured()` on the adapter; capabilities that do not implement it are
treated as always configured (true today for the local mock capability).

No network call is made here. A REMOTE capability without required
configuration (e.g. no GITHUB_TOKEN) is reported NOT_CONFIGURED rather than
guessed as connected or disconnected from a live probe -- this module never
claims network reachability it has not actually checked.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from core.capabilities.adapter import BaseCapabilityAdapter
from core.capabilities.schema import CapabilitySpec


class ConnectionKind(str, Enum):
    LOCAL = "LOCAL"
    REMOTE = "REMOTE"


class ConnectionState(str, Enum):
    LOCAL_ACTIVE = "LOCAL_ACTIVE"
    REMOTE_CONFIGURED = "REMOTE_CONFIGURED"
    REMOTE_NOT_CONFIGURED = "REMOTE_NOT_CONFIGURED"


@dataclass
class ConnectionStatus:
    capability_id: str
    name: str
    kind: ConnectionKind
    state: ConnectionState

    def to_dict(self) -> dict:
        return {
            "capability_id": self.capability_id,
            "name": self.name,
            "kind": self.kind.value,
            "state": self.state.value,
        }


def build_connection_status(
    spec: CapabilitySpec, adapter: BaseCapabilityAdapter
) -> ConnectionStatus:
    """Derive a ConnectionStatus for one registered capability adapter."""
    is_remote = bool(spec.constraints.allowed_domains)

    if not is_remote:
        return ConnectionStatus(
            capability_id=spec.capability_id,
            name=spec.name,
            kind=ConnectionKind.LOCAL,
            state=ConnectionState.LOCAL_ACTIVE,
        )

    is_configured_fn = getattr(adapter, "is_configured", None)
    configured = bool(is_configured_fn()) if callable(is_configured_fn) else True

    return ConnectionStatus(
        capability_id=spec.capability_id,
        name=spec.name,
        kind=ConnectionKind.REMOTE,
        state=(
            ConnectionState.REMOTE_CONFIGURED
            if configured
            else ConnectionState.REMOTE_NOT_CONFIGURED
        ),
    )
