#!/usr/bin/env python3
# tests/test_ui_contract_additive.py
"""Contract tests for the additive v0.1.1 UI-facing surface.

Covers:
    1. AgentStatus enum values + derive_agent_status() pure logic
    2. PermissionRequest / PendingApprovalStore
    3. ActivityFilter / ActivityRecord / build_activity_records()
    4. VaultSummary / PersonalVaultAdapter.summarize()
    5. ConnectionStatus / build_connection_status()
    6. Agent-level integration for all of the above
    7. Backward compatibility: every pre-existing public method on Agent
       keeps its exact prior behaviour/shape.

None of these tests assume network access, macOS, or Xcode.
"""

from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path

_root = Path(__file__).resolve().parents[1]
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

os.environ["AGENTCORE_PLANNER_PROVIDER"] = "mock"

from core.agent import Agent
from core.events.schema import AgentEvent, EventPhase, EventStatus, new_event
from core.runtime.status import AgentStatus, derive_agent_status
from core.runtime.permissions import PendingApprovalStore, PermissionRequest
from core.runtime.activity import ActivityFilter, build_activity_records
from core.experience.schema import Experience
from core.vault.summary import summarize_fallback_store, unsupported_summary
from core.capabilities.connections import (
    ConnectionKind,
    ConnectionState,
    build_connection_status,
)
from core.capabilities.github import GitHubCapabilityAdapter
from core.capabilities.mock_adapter import MockEchoCapabilityAdapter


class TestAgentStatusEnum(unittest.TestCase):
    def test_enum_values_are_stable_strings(self):
        self.assertEqual(AgentStatus.READY.value, "READY")
        self.assertEqual(AgentStatus.THINKING.value, "THINKING")
        self.assertEqual(AgentStatus.RUNNING.value, "RUNNING")
        self.assertEqual(AgentStatus.OFFLINE.value, "OFFLINE")

    def test_offline_when_vault_unavailable_regardless_of_events(self):
        ev = new_event(run_id="R1", phase=EventPhase.EXECUTE.value, action="x")
        self.assertEqual(
            derive_agent_status(vault_available=False, last_event=ev),
            AgentStatus.OFFLINE,
        )

    def test_ready_when_no_event_and_vault_available(self):
        self.assertEqual(
            derive_agent_status(vault_available=True, last_event=None),
            AgentStatus.READY,
        )

    def test_thinking_phase_mapping(self):
        for phase in (EventPhase.TASK_STARTED, EventPhase.PLAN, EventPhase.PLAN_CREATED):
            ev = new_event(run_id="R1", phase=phase.value, action="x")
            self.assertEqual(
                derive_agent_status(vault_available=True, last_event=ev),
                AgentStatus.THINKING,
                msg=f"phase={phase}",
            )

    def test_running_phase_mapping(self):
        for phase in (EventPhase.EXECUTE, EventPhase.VERIFY, EventPhase.EXPERIENCE):
            ev = new_event(run_id="R1", phase=phase.value, action="x")
            self.assertEqual(
                derive_agent_status(vault_available=True, last_event=ev),
                AgentStatus.RUNNING,
                msg=f"phase={phase}",
            )

    def test_terminal_phase_returns_to_ready(self):
        for phase in (EventPhase.TASK_COMPLETED, EventPhase.TASK_FAILED, EventPhase.RESULT):
            ev = new_event(run_id="R1", phase=phase.value, action="x")
            self.assertEqual(
                derive_agent_status(vault_available=True, last_event=ev),
                AgentStatus.READY,
                msg=f"phase={phase}",
            )


class TestPendingApprovalStore(unittest.TestCase):
    def test_set_get_clear_roundtrip(self):
        store = PendingApprovalStore()
        self.assertIsNone(store.get("RUN-1"))

        req = PermissionRequest(
            run_id="RUN-1",
            capability_id="github_integration",
            action="create_issue_comment",
            reason="requires explicit user approval",
        )
        store.set(req)
        fetched = store.get("RUN-1")
        self.assertIsNotNone(fetched)
        self.assertEqual(fetched.run_id, "RUN-1")
        self.assertEqual(fetched.capability_id, "github_integration")

        d = fetched.to_dict()
        self.assertEqual(set(d.keys()), {"run_id", "capability_id", "action", "reason", "requested_at"})

        self.assertTrue(store.clear("RUN-1"))
        self.assertIsNone(store.get("RUN-1"))
        self.assertFalse(store.clear("RUN-1"))


class TestActivityRecords(unittest.TestCase):
    def _exp(self, run_id, outcome, duration=1.5):
        return Experience(
            run_id=run_id,
            goal=f"goal-{run_id}",
            project_id="default",
            outcome=outcome,
            duration=duration,
        )

    def test_filter_all_success_failed(self):
        exps = [
            self._exp("R1", "success"),
            self._exp("R2", "failure"),
            self._exp("R3", "success"),
        ]
        all_records = build_activity_records(exps, ActivityFilter.ALL)
        self.assertEqual(len(all_records), 3)
        # newest-first ordering: last appended Experience should come first
        self.assertEqual(all_records[0].run_id, "R3")

        success = build_activity_records(exps, ActivityFilter.SUCCESS)
        self.assertTrue(all(r.is_success for r in success))
        self.assertEqual({r.run_id for r in success}, {"R1", "R3"})

        failed = build_activity_records(exps, ActivityFilter.FAILED)
        self.assertTrue(all(not r.is_success for r in failed))
        self.assertEqual({r.run_id for r in failed}, {"R2"})

    def test_duration_never_guessed(self):
        exp = self._exp("R1", "success", duration=0.0)
        records = build_activity_records([exp])
        self.assertEqual(records[0].duration_seconds, 0.0)


class TestVaultSummary(unittest.TestCase):
    def test_summarize_groups_by_category(self):
        store = {
            "k1": {"data": "a", "category": "user_preference"},
            "k2": {"data": "b", "category": "run_history"},
            "k3": {"data": "c", "category": "run_history"},
        }
        summary = summarize_fallback_store(store, is_local=True)
        self.assertTrue(summary.supported)
        self.assertEqual(summary.total_items, 3)
        counts = {c.name: c.item_count for c in summary.categories}
        self.assertEqual(counts, {"user_preference": 1, "run_history": 2})

    def test_unsupported_summary_is_explicit(self):
        summary = unsupported_summary()
        self.assertFalse(summary.supported)
        self.assertEqual(summary.total_items, 0)


class TestConnectionStatus(unittest.TestCase):
    def test_local_capability_is_local_active(self):
        adapter = MockEchoCapabilityAdapter()
        status = build_connection_status(adapter.get_spec(), adapter)
        self.assertEqual(status.kind, ConnectionKind.LOCAL)
        self.assertEqual(status.state, ConnectionState.LOCAL_ACTIVE)

    def test_github_without_token_is_not_configured(self):
        os.environ.pop("GITHUB_TOKEN", None)
        adapter = GitHubCapabilityAdapter(github_token=None)
        status = build_connection_status(adapter.get_spec(), adapter)
        self.assertEqual(status.kind, ConnectionKind.REMOTE)
        self.assertEqual(status.state, ConnectionState.REMOTE_NOT_CONFIGURED)

    def test_github_with_token_is_configured(self):
        adapter = GitHubCapabilityAdapter(github_token="fake-token-for-test")
        status = build_connection_status(adapter.get_spec(), adapter)
        self.assertEqual(status.state, ConnectionState.REMOTE_CONFIGURED)


class TestAgentIntegration(unittest.TestCase):
    """End-to-end: the new methods on Agent itself, backed by real subsystems."""

    def setUp(self):
        self.agent = Agent(project_id="default")

    def test_current_status_ready_before_any_run(self):
        # A fresh Agent has an empty EventBus -> READY (vault should be available
        # via local fallback store even with no external vault client).
        status = self.agent.current_status()
        self.assertIn(status, (AgentStatus.READY, AgentStatus.OFFLINE))

    def test_current_status_ready_after_successful_run(self):
        self.agent.run(goal="Inspect system architecture")
        self.assertEqual(self.agent.current_status(), AgentStatus.READY)

    def test_run_events_ordered_and_nonempty(self):
        result = self.agent.run(goal="Inspect system architecture")
        events = self.agent.run_events(result.run_id)
        self.assertGreater(len(events), 0)
        phases = [e.phase for e in events]
        # TASK_STARTED must precede a terminal phase for this run.
        self.assertIn(EventPhase.TASK_STARTED.value, phases)
        self.assertTrue(
            EventPhase.TASK_COMPLETED.value in phases
            or EventPhase.TASK_FAILED.value in phases
        )
        self.assertLess(
            phases.index(EventPhase.TASK_STARTED.value),
            max(
                i for i, p in enumerate(phases)
                if p in (EventPhase.TASK_COMPLETED.value, EventPhase.TASK_FAILED.value)
            ),
        )

    def test_pending_approval_recorded_on_real_denial(self):
        result = self.agent.run(
            goal="Post a comment",
            capability_dispatch=(
                "github_integration",
                {"action": "create_issue_comment", "owner": "o", "repo": "r", "issue_number": 1, "body": "hi"},
            ),
            user_approved=False,
        )
        pending = self.agent.pending_approval(result.run_id)
        self.assertIsNotNone(pending)
        self.assertEqual(pending.capability_id, "github_integration")
        self.assertIn("approval", pending.reason.lower())

    def test_pending_approval_none_when_not_denied(self):
        result = self.agent.run(goal="Just inspect, no capability dispatch")
        self.assertIsNone(self.agent.pending_approval(result.run_id))

    def test_cancel_unknown_run_returns_false(self):
        self.assertFalse(self.agent.cancel("RUN-does-not-exist"))

    def test_cancel_completed_run_returns_false(self):
        result = self.agent.run(goal="Inspect system architecture")
        self.assertFalse(self.agent.cancel(result.run_id))

    def test_list_activity_reflects_real_runs(self):
        before = len(self.agent.list_activity(ActivityFilter.ALL))
        self.agent.run(goal="Another goal for activity test")
        after = self.agent.list_activity(ActivityFilter.ALL)
        self.assertEqual(len(after), before + 1)
        self.assertTrue(all(hasattr(r, "run_id") for r in after))

    def test_vault_summary_reflects_real_remember_call(self):
        before = self.agent.vault_summary()
        self.assertTrue(before.supported)
        self.agent._vault.store_context(
            key="ui_contract_test_key", data={"value": "x"}, category="user_preference"
        )
        after = self.agent.vault_summary()
        self.assertGreaterEqual(after.total_items, before.total_items + 1)

    def test_list_connections_includes_registered_capabilities(self):
        connections = self.agent.list_connections()
        ids = {c.capability_id for c in connections}
        self.assertIn("mock.echo", ids)
        self.assertIn("github_integration", ids)
        for c in connections:
            if c.capability_id == "mock.echo":
                self.assertEqual(c.kind, ConnectionKind.LOCAL)


class TestBackwardCompatibility(unittest.TestCase):
    """The 10 pre-existing public Agent methods keep their exact prior shape."""

    def setUp(self):
        self.agent = Agent(project_id="default")

    def test_run_shape_unchanged(self):
        res = self.agent.run(goal="Inspect system architecture")
        for attr in (
            "run_id", "project_id", "goal", "status", "phase", "plan_steps",
            "authorized", "verification_verdict", "duration_seconds",
            "llm_calls", "experience_recorded", "errors", "observations",
        ):
            self.assertTrue(hasattr(res, attr), msg=f"missing {attr}")
        self.assertEqual(res.status, "COMPLETED")
        self.assertTrue(res.authorized)

    def test_resume_unknown_run_unchanged(self):
        # Pre-existing behaviour, unmodified by this change: Kernel.resume()
        # raises for an unknown run_id. Only a run_id previously passed to
        # the new Agent.cancel() short-circuits before reaching Kernel.
        from core.kernel.kernel import KernelError

        with self.assertRaises(KernelError):
            self.agent.resume("RUN-never-existed")

    def test_remember_retrieve_update_memory_unchanged(self):
        mem = self.agent._memory.remember(content="k:v", memory_type="user_context")
        self.assertIsNotNone(mem.memory_id)
        results = self.agent._vault.retrieve_context(query="")
        self.assertIsInstance(results, list)

    def test_execute_capability_denied_shape_unchanged(self):
        res = self.agent.execute_capability(
            "github_integration",
            {"action": "create_issue_comment", "owner": "o", "repo": "r"},
            user_approved=False,
        )
        self.assertEqual(res.status, "DENIED")
        self.assertIsNotNone(res.error)

    def test_execute_capability_mock_echo_unchanged(self):
        res = self.agent.execute_capability("mock.echo", {"action": "read", "text": "hi"})
        self.assertEqual(res.status, "SUCCESS")


if __name__ == "__main__":
    unittest.main()
