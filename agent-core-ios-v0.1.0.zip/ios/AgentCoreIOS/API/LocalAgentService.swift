// ios/AgentCoreIOS/API/LocalAgentService.swift
// Native iOS Local Agent API Service Implementation

import Foundation

/// Public native LocalAgentService implementing LocalAgentServiceProtocol.
/// Communicates directly with native AgentRuntime, preserving offline local-first security & policy boundaries.
public final class LocalAgentService: LocalAgentServiceProtocol, @unchecked Sendable {
    private let runtime: AgentRuntime

    public init(runtime: AgentRuntime? = nil) {
        self.runtime = runtime ?? AgentRuntime()
    }

    public func run(goal: String, userApproved: Bool = false) async -> AgentRunResult {
        return await runtime.run(goal: goal, userApproved: userApproved)
    }

    public func cancelRun(runId: String) async -> AgentRunResult {
        return await runtime.cancelRun(runId: runId)
    }

    public func resume(runId: String) async -> AgentRunResult {
        return await runtime.resume(runId: runId)
    }

    public func remember(key: String, value: String) async -> MemoryResult {
        return await runtime.remember(key: key, value: value)
    }

    public func retrieve(query: String) async -> [MemoryItem] {
        return await runtime.retrieve(query: query)
    }

    public func updateMemory(key: String, value: String, userApproved: Bool = false) async -> MemoryResult {
        return await runtime.updateMemory(key: key, value: value, userApproved: userApproved)
    }

    public func forget(key: String) async -> MemoryResult {
        return await runtime.forget(key: key)
    }

    public func listCapabilities() async -> [Capability] {
        return await runtime.listCapabilities()
    }

    public func executeCapability(capabilityId: String, input: [String: String], userApproved: Bool = false) async -> CapabilityResult {
        return await runtime.executeCapability(capabilityId: capabilityId, input: input, userApproved: userApproved)
    }

    public func getRun(runId: String) async -> AgentRunResult? {
        return await runtime.getRun(runId: runId)
    }

    public func getExperience() async -> [Experience] {
        return await runtime.getExperience()
    }

    public func health() async -> AgentHealth {
        return await runtime.health()
    }

    // MARK: - Additive UI Contract Methods Forwarding

    public func currentAgentStatus() async -> AgentStatus {
        return await runtime.currentAgentStatus()
    }

    public func runStreaming(
        goal: String,
        userApproved: Bool = false,
        capabilityDispatch: (capabilityId: String, input: [String: String])? = nil,
        onEvent: @escaping @Sendable (AgentRunEvent) -> Void
    ) async -> AgentRunResult {
        return await runtime.runStreaming(
            goal: goal,
            userApproved: userApproved,
            capabilityDispatch: capabilityDispatch,
            onEvent: onEvent
        )
    }

    public func cancel(runId: String) async -> Bool {
        return await runtime.cancel(runId: runId)
    }

    public func pendingApproval(runId: String) async -> PermissionRequest? {
        return await runtime.pendingApproval(runId: runId)
    }

    public func listActivity(filter: ActivityFilter = .all) async -> [ActivityRecord] {
        return await runtime.listActivity(filter: filter)
    }

    public func vaultSummary() async -> VaultSummary {
        return await runtime.vaultSummary()
    }

    public func listConnections() async -> [ConnectionStatus] {
        return await runtime.listConnections()
    }
}
