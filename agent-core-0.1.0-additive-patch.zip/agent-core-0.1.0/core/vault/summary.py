# core/vault/summary.py
"""Vault Summary — UI-facing category/count view over real vault storage.

Additive only. Does not change `BaseVaultAdapter`'s abstract contract (no
new abstract method is introduced, so no existing subclass can break).
`summarize_fallback_store` is a pure function over the exact dict shape
`PersonalVaultAdapter` already persists (`core/vault/adapter.py`
`_fallback_store`): ``{key: {"data": ..., "category": ...}}``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class VaultCategory:
    name: str
    item_count: int

    def to_dict(self) -> dict:
        return {"name": self.name, "item_count": self.item_count}


@dataclass
class VaultSummary:
    """Real, storage-derived vault summary. Never fabricated."""

    is_local: bool
    total_items: int
    categories: list[VaultCategory] = field(default_factory=list)
    supported: bool = True  # False when the active vault adapter cannot summarize

    def to_dict(self) -> dict:
        return {
            "is_local": self.is_local,
            "total_items": self.total_items,
            "categories": [c.to_dict() for c in self.categories],
            "supported": self.supported,
        }


def summarize_fallback_store(
    fallback_store: dict[str, dict[str, Any]],
    is_local: bool,
) -> VaultSummary:
    """Group the real fallback-vault dict by category and count items."""
    counts: dict[str, int] = {}
    for entry in fallback_store.values():
        category = str(entry.get("category") or "uncategorized")
        counts[category] = counts.get(category, 0) + 1

    categories = [
        VaultCategory(name=name, item_count=count)
        for name, count in sorted(counts.items())
    ]
    return VaultSummary(
        is_local=is_local,
        total_items=len(fallback_store),
        categories=categories,
        supported=True,
    )


def unsupported_summary() -> VaultSummary:
    """Explicit, honest result when the active adapter cannot be summarized."""
    return VaultSummary(is_local=False, total_items=0, categories=[], supported=False)
