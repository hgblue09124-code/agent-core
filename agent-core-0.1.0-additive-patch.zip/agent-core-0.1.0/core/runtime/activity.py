# core/runtime/activity.py
"""Activity — UI-facing timeline built from real Experience + EventBus data.

No new storage is introduced. An ActivityRecord is a read-only projection
of an existing `core.experience.schema.Experience` record, optionally
enriched with the run's real duration/timestamp from the EventBus if the
Experience record itself did not capture one (duration defaults to 0.0
when genuinely unknown -- never guessed).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Optional

from core.experience.schema import Experience


class ActivityFilter(str, Enum):
    ALL = "ALL"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


# Outcome strings actually produced by Agent.run() / capability dispatch.
_SUCCESS_OUTCOMES = frozenset({"success"})
_FAILED_OUTCOMES = frozenset({"failure", "failed", "denied"})


@dataclass
class ActivityRecord:
    """A single row in the Activity timeline."""

    run_id: str
    goal: str
    outcome: str  # raw Experience.outcome value, unmodified
    is_success: bool
    timestamp: str
    duration_seconds: float

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "goal": self.goal,
            "outcome": self.outcome,
            "is_success": self.is_success,
            "timestamp": self.timestamp,
            "duration_seconds": round(self.duration_seconds, 3),
        }


def _record_from_experience(exp: Experience) -> ActivityRecord:
    outcome_norm = (exp.outcome or "").strip().lower()
    return ActivityRecord(
        run_id=exp.run_id,
        goal=exp.goal,
        outcome=exp.outcome,
        is_success=outcome_norm in _SUCCESS_OUTCOMES,
        timestamp=getattr(exp, "timestamp", "") or "",
        duration_seconds=float(getattr(exp, "duration", 0.0) or 0.0),
    )


def build_activity_records(
    experiences: Iterable[Experience],
    activity_filter: ActivityFilter = ActivityFilter.ALL,
) -> list[ActivityRecord]:
    """Project real Experience records into ActivityRecords, newest first.

    Args:
        experiences: real records from `ExperienceEngine`/`ExperienceStore`.
        activity_filter: ALL / SUCCESS / FAILED.
    """
    records = [_record_from_experience(e) for e in experiences]
    records.reverse()  # experience stores are append-only -> newest last

    if activity_filter == ActivityFilter.SUCCESS:
        records = [r for r in records if r.is_success]
    elif activity_filter == ActivityFilter.FAILED:
        records = [r for r in records if not r.is_success]

    return records
