// ios/AgentCoreIOS/API/AgentAPIModels.swift
// Native iOS Local Agent API v0.1 Result & Spec Codable Models

import Foundation

/// Status enum representing operational outcomes deterministically.
public enum Status: String, Codable, Sendable {
    case success = "SUCCESS"
    case failed = "FAILED"
    case denied = "DENIED"
    case notExecuted = "NOT_EXECUTED"
}

/// Codable result model for Agent run and resume execution.
public struct AgentRunResult: Codable, Sendable, Identifiable {
    public var id: String { runId }
    public let runId: String
    public let status: Status
    public let goal: String
    public let output: String?
    public let createdAt: String
    public let updatedAt: String
    public let errorCode: String?
    public let errorMessage: String?
    public let planSteps: [String]
    public let authorized: Bool
    public let verificationVerdict: String

    public init(
        runId: String,
        status: Status,
        goal: String,
        output: String? = nil,
        createdAt: String = ISO8601DateFormatter().string(from: Date()),
        updatedAt: String = ISO8601DateFormatter().string(from: Date()),
        errorCode: String? = nil,
        errorMessage: String? = nil,
        planSteps: [String] = [],
        authorized: Bool = true,
        verificationVerdict: String = "PASS"
    ) {
        self.runId = runId
        self.status = status
        self.goal = goal
        self.output = output
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.errorCode = errorCode
        self.errorMessage = errorMessage
        self.planSteps = planSteps
        self.authorized = authorized
        self.verificationVerdict = verificationVerdict
    }
}

/// Codable memory item stored in local memory layer.
public struct MemoryItem: Codable, Sendable, Identifiable {
    public var id: String { memoryId }
    public let memoryId: String
    public let key: String
    public let value: String
    public let memoryType: String
    public let importance: Double
    public let createdAt: String
    public let updatedAt: String

    public init(
        memoryId: String,
        key: String,
        value: String,
        memoryType: String = "short_term",
        importance: Double = 0.5,
        createdAt: String = ISO8601DateFormatter().string(from: Date()),
        updatedAt: String = ISO8601DateFormatter().string(from: Date())
    ) {
        self.memoryId = memoryId
        self.key = key
        self.value = value
        self.memoryType = memoryType
        self.importance = importance
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

/// Result model for memory creation/update operations.
public struct MemoryResult: Codable, Sendable {
    public let status: Status
    public let item: MemoryItem?
    public let errorMessage: String?

    public init(status: Status, item: MemoryItem? = nil, errorMessage: String? = nil) {
        self.status = status
        self.item = item
        self.errorMessage = errorMessage
    }
}

/// Specification model for pluggable capability modules.
public struct Capability: Codable, Sendable, Identifiable {
    public var id: String { capabilityId }
    public let capabilityId: String
    public let name: String
    public let description: String
    public let version: String
    public let readOnly: Bool
    public let requiresUserApproval: Bool
    /// Additive v0.1.1 field. Defaults to `false` so every pre-existing
    /// call site (which omits this parameter) compiles unchanged and
    /// keeps its prior LOCAL classification in `ConnectionStatus`.
    public let isRemote: Bool

    public init(
        capabilityId: String,
        name: String,
        description: String,
        version: String = "1.0.0",
        readOnly: Bool = true,
        requiresUserApproval: Bool = false,
        isRemote: Bool = false
    ) {
        self.capabilityId = capabilityId
        self.name = name
        self.description = description
        self.version = version
        self.readOnly = readOnly
        self.requiresUserApproval = requiresUserApproval
        self.isRemote = isRemote
    }
}

/// Result model for capability execution.
public struct CapabilityResult: Codable, Sendable {
    public let capabilityId: String
    public let status: Status
    public let output: String?
    public let errorMessage: String?

    public init(capabilityId: String, status: Status, output: String? = nil, errorMessage: String? = nil) {
        self.capabilityId = capabilityId
        self.status = status
        self.output = output
        self.errorMessage = errorMessage
    }
}

/// Codable experience record for agent learning traceability.
public struct Experience: Codable, Sendable, Identifiable {
    public var id: String { runId }
    public let runId: String
    public let goal: String
    public let outcome: String
    public let timestamp: String

    public init(
        runId: String,
        goal: String,
        outcome: String,
        timestamp: String = ISO8601DateFormatter().string(from: Date())
    ) {
        self.runId = runId
        self.goal = goal
        self.outcome = outcome
        self.timestamp = timestamp
    }
}

/// Health and diagnostic status model for native agent runtime.
public struct AgentHealth: Codable, Sendable {
    public let status: String
    public let isLocalOnly: Bool
    public let providerName: String
    public let providerStatus: String
    public let isVaultAvailable: Bool
    public let storagePath: String
    public let activeCapabilitiesCount: Int

    public init(
        status: String = "HEALTHY",
        isLocalOnly: Bool = true,
        providerName: String = "LocalDeterministicPlanner",
        providerStatus: String = "DETERMINISTIC_TEST",
        isVaultAvailable: Bool = true,
        storagePath: String = "Application Support/AgentCore/",
        activeCapabilitiesCount: Int = 2
    ) {
        self.status = status
        self.isLocalOnly = isLocalOnly
        self.providerName = providerName
        self.providerStatus = providerStatus
        self.isVaultAvailable = isVaultAvailable
        self.storagePath = storagePath
        self.activeCapabilitiesCount = activeCapabilitiesCount
    }
}

// MARK: - Additive v0.1.1 UI-facing contract
//
// Everything below mirrors the additive Python surface in
// `core/runtime/status.py`, `core/runtime/permissions.py`,
// `core/runtime/activity.py`, `core/vault/summary.py`, and
// `core/capabilities/connections.py`. Enum raw values match the Python
// string values exactly so both sides agree on wire format. No existing
// type or method above this section is modified.

/// Coarse agent activity status, mirrors `core.runtime.status.AgentStatus`.
public enum AgentStatus: String, Codable, Sendable {
    case ready = "READY"
    case thinking = "THINKING"
    case running = "RUNNING"
    case offline = "OFFLINE"
}

/// Phase vocabulary, mirrors `core.events.schema.EventPhase` 1:1.
/// Not every case is emitted by the current (synchronous) runtime --
/// see `AgentRuntime.runStreaming` for which phases are real today.
public enum AgentEventPhase: String, Codable, Sendable {
    case taskCreated = "TASK_CREATED"
    case taskStarted = "TASK_STARTED"
    case plan = "PLAN"
    case planCreated = "PLAN_CREATED"
    case knowledge = "KNOWLEDGE"
    case memoryUpdated = "MEMORY_UPDATED"
    case actionStarted = "ACTION_STARTED"
    case execute = "EXECUTE"
    case actionCompleted = "ACTION_COMPLETED"
    case observe = "OBSERVE"
    case verify = "VERIFY"
    case verificationFailed = "VERIFICATION_FAILED"
    case recovery = "RECOVERY"
    case checkpoint = "CHECKPOINT"
    case experience = "EXPERIENCE"
    case experienceRecorded = "EXPERIENCE_RECORDED"
    case evaluation = "EVALUATION"
    case taskCompleted = "TASK_COMPLETED"
    case taskFailed = "TASK_FAILED"
    case result = "RESULT"
}

/// Status vocabulary, mirrors `core.events.schema.EventStatus` 1:1.
public enum AgentEventStatus: String, Codable, Sendable {
    case pending = "PENDING"
    case running = "RUNNING"
    case pass = "PASS"
    case fail = "FAIL"
    case ok = "OK"
    case error = "ERROR"
}

/// A single lifecycle event, mirrors `core.events.schema.AgentEvent`.
public struct AgentRunEvent: Codable, Sendable, Identifiable {
    public var id: String { eventId }
    public let eventId: String
    public let runId: String
    public let phase: AgentEventPhase
    public let action: String
    public let status: AgentEventStatus
    public let timestamp: String
    public let message: String
    public let duration: Double

    public init(
        eventId: String = "EV-" + UUID().uuidString.prefix(10).lowercased(),
        runId: String,
        phase: AgentEventPhase,
        action: String,
        status: AgentEventStatus = .running,
        timestamp: String = ISO8601DateFormatter().string(from: Date()),
        message: String = "",
        duration: Double = 0.0
    ) {
        self.eventId = eventId
        self.runId = runId
        self.phase = phase
        self.action = action
        self.status = status
        self.timestamp = timestamp
        self.message = message
        self.duration = duration
    }
}

/// A real, already-issued policy denial kept for later retrieval.
/// Mirrors `core.runtime.permissions.PermissionRequest`.
public struct PermissionRequest: Codable, Sendable {
    public let runId: String
    public let capabilityId: String
    public let action: String
    public let reason: String
    public let requestedAt: String

    public init(
        runId: String,
        capabilityId: String,
        action: String,
        reason: String,
        requestedAt: String = ISO8601DateFormatter().string(from: Date())
    ) {
        self.runId = runId
        self.capabilityId = capabilityId
        self.action = action
        self.reason = reason
        self.requestedAt = requestedAt
    }
}

/// Mirrors `core.runtime.activity.ActivityFilter`.
public enum ActivityFilter: String, Codable, Sendable {
    case all = "ALL"
    case success = "SUCCESS"
    case failed = "FAILED"
}

/// A single Activity-timeline row, mirrors `core.runtime.activity.ActivityRecord`.
public struct ActivityRecord: Codable, Sendable, Identifiable {
    public var id: String { runId }
    public let runId: String
    public let goal: String
    public let outcome: String
    public let isSuccess: Bool
    public let timestamp: String
    public let durationSeconds: Double

    public init(
        runId: String,
        goal: String,
        outcome: String,
        isSuccess: Bool,
        timestamp: String,
        durationSeconds: Double
    ) {
        self.runId = runId
        self.goal = goal
        self.outcome = outcome
        self.isSuccess = isSuccess
        self.timestamp = timestamp
        self.durationSeconds = durationSeconds
    }
}

/// Mirrors `core.vault.summary.VaultCategory`.
public struct VaultCategory: Codable, Sendable {
    public let name: String
    public let itemCount: Int

    public init(name: String, itemCount: Int) {
        self.name = name
        self.itemCount = itemCount
    }
}

/// Mirrors `core.vault.summary.VaultSummary`.
public struct VaultSummary: Codable, Sendable {
    public let isLocal: Bool
    public let totalItems: Int
    public let categories: [VaultCategory]
    /// False when the active vault store cannot be summarized -- an
    /// explicit, honest state rather than a fabricated empty summary.
    public let supported: Bool

    public init(isLocal: Bool, totalItems: Int, categories: [VaultCategory], supported: Bool = true) {
        self.isLocal = isLocal
        self.totalItems = totalItems
        self.categories = categories
        self.supported = supported
    }
}

/// Mirrors `core.capabilities.connections.ConnectionKind`.
public enum ConnectionKind: String, Codable, Sendable {
    case local = "LOCAL"
    case remote = "REMOTE"
}

/// Mirrors `core.capabilities.connections.ConnectionState`.
public enum ConnectionState: String, Codable, Sendable {
    case localActive = "LOCAL_ACTIVE"
    case remoteConfigured = "REMOTE_CONFIGURED"
    case remoteNotConfigured = "REMOTE_NOT_CONFIGURED"
}

/// Mirrors `core.capabilities.connections.ConnectionStatus`.
public struct ConnectionStatus: Codable, Sendable, Identifiable {
    public var id: String { capabilityId }
    public let capabilityId: String
    public let name: String
    public let kind: ConnectionKind
    public let state: ConnectionState

    public init(capabilityId: String, name: String, kind: ConnectionKind, state: ConnectionState) {
        self.capabilityId = capabilityId
        self.name = name
        self.kind = kind
        self.state = state
    }
}
