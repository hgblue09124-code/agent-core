# core/runtime/permissions.py
"""Pending Approval — additive, run-scoped record of a real policy denial.

This does not change PolicyEngine.authorize_capability() or
Agent.execute_capability() behaviour or return values. It only *remembers*
a denial that already happened, indexed by run_id, so a UI can later ask
"is there a permission request waiting for this run?" instead of having to
catch it synchronously at the moment of denial.

Nothing here is fabricated: a PermissionRequest is only ever created from a
real CapabilityResult with status == "DENIED" produced by the existing
policy engine.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class PermissionRequest:
    """A real, already-issued policy denial, kept for later UI retrieval."""

    run_id: str
    capability_id: str
    action: str
    reason: str
    requested_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "capability_id": self.capability_id,
            "action": self.action,
            "reason": self.reason,
            "requested_at": self.requested_at,
        }


class PendingApprovalStore:
    """Thread-safe in-memory map of run_id -> PermissionRequest.

    In-memory only, matching the process lifetime of the rest of the
    non-persisted runtime state (EventBus is also in-memory). Persisting
    this across process restarts is future work and is not claimed here.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._pending: dict[str, PermissionRequest] = {}

    def set(self, request: PermissionRequest) -> None:
        with self._lock:
            self._pending[request.run_id] = request

    def get(self, run_id: str) -> Optional[PermissionRequest]:
        with self._lock:
            return self._pending.get(run_id)

    def clear(self, run_id: str) -> bool:
        with self._lock:
            if run_id in self._pending:
                del self._pending[run_id]
                return True
            return False
