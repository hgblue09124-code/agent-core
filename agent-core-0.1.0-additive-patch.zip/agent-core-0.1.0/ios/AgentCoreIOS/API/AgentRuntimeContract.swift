// ios/AgentCoreIOS/API/AgentRuntimeContract.swift
// Native iOS Local Agent API Service Protocol Contract

import Foundation

/// Protocol contract for the Native Local Agent Service called directly by iOS SwiftUI UI.
public protocol LocalAgentServiceProtocol: Sendable {
    /// Execute a task goal through the local Agent orchestration loop.
    func run(goal: String, userApproved: Bool) async -> AgentRunResult

    /// Resume an interrupted/non-terminal run from local disk checkpoint.
    func resume(runId: String) async -> AgentRunResult

    /// Remember a key-value personal fact in local memory.
    func remember(key: String, value: String) async -> MemoryResult

    /// Retrieve stored memory items matching a query.
    func retrieve(query: String) async -> [MemoryItem]

    /// Update an existing memory item, enforcing policy write approval checks.
    func updateMemory(key: String, value: String, userApproved: Bool) async -> MemoryResult

    /// List all registered local capabilities and specifications.
    func listCapabilities() async -> [Capability]

    /// Execute a capability action, enforcing PolicyEngine authorization checks.
    func executeCapability(capabilityId: String, input: [String: String], userApproved: Bool) async -> CapabilityResult

    /// Retrieve detailed run lifecycle state by run ID.
    func getRun(runId: String) async -> AgentRunResult?

    /// Retrieve historical experience records for offline learning traceability.
    func getExperience() async -> [Experience]

    /// Return diagnostic health status of the local native agent service.
    func health() async -> AgentHealth

    // MARK: - Additive v0.1.1 UI-facing contract
    // None of the methods above this line are modified. Everything below
    // is new surface for the Home/Execute/Activity/Vault/Connections UI
    // concept; the old `run(goal:userApproved:)` above is untouched and
    // keeps its exact prior behavior for any existing caller.

    /// Single source of truth for "what is my agent doing right now".
    func currentAgentStatus() async -> AgentStatus

    /// Execute a task goal with live lifecycle events delivered as they
    /// happen, and optionally dispatch one capability as part of the run
    /// (mirrors the Python `Agent.run(capability_dispatch=...)` path).
    /// This does not replace `run(goal:userApproved:)` above -- it is an
    /// additional entry point for UI that wants to observe progress.
    func runStreaming(
        goal: String,
        userApproved: Bool,
        capabilityDispatch: (capabilityId: String, input: [String: String])?,
        onEvent: @escaping @Sendable (AgentRunEvent) -> Void
    ) async -> AgentRunResult

    /// Cancel a non-terminal run. Returns false for unknown or already
    /// terminal runs -- see `AgentRuntime.cancel` for the honest
    /// limitation this implies under the current synchronous execution
    /// model.
    func cancel(runId: String) async -> Bool

    /// Return the real, previously-issued permission request pending for
    /// this run, if any.
    func pendingApproval(runId: String) async -> PermissionRequest?

    /// Real Activity timeline, filterable.
    func listActivity(filter: ActivityFilter) async -> [ActivityRecord]

    /// Real vault category/item-count summary.
    func vaultSummary() async -> VaultSummary

    /// Real local/remote connection status for every registered capability.
    func listConnections() async -> [ConnectionStatus]
}
