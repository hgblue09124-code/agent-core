# Danh sách file trong gói này (mirror đúng đường dẫn trong repo agent-core)

## File MỚI (thêm hoàn toàn)
- core/runtime/status.py
- core/runtime/permissions.py
- core/runtime/activity.py
- core/vault/summary.py
- core/capabilities/connections.py
- tests/test_ui_contract_additive.py

## File SỬA (additive, giữ nguyên method/field cũ)
- core/agent.py
- core/vault/adapter.py           (thêm is_operational(), summarize())
- core/capabilities/github.py     (thêm is_configured())
- ios/AgentCoreIOS/API/AgentAPIModels.swift      (thêm model mới + field Capability.isRemote)
- ios/AgentCoreIOS/API/AgentRuntimeContract.swift (thêm 6 method mới vào protocol)

## CHƯA đụng — Jules cần tự làm tiếp (xem bản handover kỹ thuật)
- ios/AgentCoreIOS/Runtime/AgentRuntime.swift   (protocol mới yêu cầu 6 method chưa implement -> KHÔNG COMPILE cho tới khi xong)
- ios/AgentCoreIOS/API/LocalAgentService.swift  (cần passthrough 6 method)
- ios/AgentCoreIOS/Storage/LocalVaultStore.swift (cần thêm summarize())
- ios/Tests/LocalAgentServiceTests.swift        (chưa có test cho phần mới)

Chép đè các file trên vào đúng vị trí trong repo thật, hoặc dùng file zip đầy đủ (agent-core-0.1.0-additive-patch.zip) để thay cả thư mục.
